package com.example.rest.increment.evaluationtask;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EvaluationTaskApplicationTests {

	@Test
	public void contextLoads() {
	}

}

