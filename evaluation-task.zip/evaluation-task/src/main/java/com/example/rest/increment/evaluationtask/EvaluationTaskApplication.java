package com.example.rest.increment.evaluationtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluationTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvaluationTaskApplication.class, args);
	}

}

