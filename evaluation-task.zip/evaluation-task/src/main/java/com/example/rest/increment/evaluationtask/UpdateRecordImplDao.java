package com.example.rest.increment.evaluationtask;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Class containing methods calling to DB to update the number
 *
 */
@Component
public class UpdateRecordImplDao {

	@Autowired
	ConnectionPool jdbcObj;
	
	public DataSource dataSource;
	
	// Constructor
	public UpdateRecordImplDao(ConnectionPool jdbcObj, DataSource dataSource) {
		super();
		this.jdbcObj = jdbcObj;
		try {
			this.dataSource = jdbcObj.setUpPool();
		} catch (Exception e) {
			System.out.println("Exception Occured");
			e.printStackTrace();
		}
	}

	
	/**
	 * This method gets connection from pool and calls the SP to update the number.
	 */
	void incrementAndUpdate() {
		Connection connObj = null;
		CallableStatement cstmt = null;
		try {
			connObj = dataSource.getConnection();
			String SQL = "{call new_procedure ()}";
			cstmt = connObj.prepareCall (SQL);
			cstmt.execute();
		}  catch(Exception sqlException) {
      sqlException.printStackTrace();
  } finally {
      try {
          if(cstmt != null) {
          	cstmt.close();
          }
          // Closing Connection Object
          if(connObj != null) {
              connObj.close();
          }
      } catch(Exception sqlException) {
          sqlException.printStackTrace();
      }
  }
	}
}
