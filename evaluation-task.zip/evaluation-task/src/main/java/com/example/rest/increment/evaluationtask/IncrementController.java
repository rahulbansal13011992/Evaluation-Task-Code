package com.example.rest.increment.evaluationtask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class containing rest services.
 *
 */
@RestController
public class IncrementController {

	@Autowired
	UpdateRecordImplDao updateRecordImplDao;

	// This rest service is need to be called to increment the number
	@GetMapping(path = "/incrementnumber")
	public String incrementNumberService() {

		updateRecordImplDao.incrementAndUpdate();

		return "done";
	}

}
